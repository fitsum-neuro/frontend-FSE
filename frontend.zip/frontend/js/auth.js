 const firebaseConfig = {
  apiKey: "AIzaSyDwPJ4JUS_l3WithXuSB8-x8DpEgfYROts",
  authDomain: "delta-rental-db03f.firebaseapp.com",
  projectId: "delta-rental-db03f",
  storageBucket: "delta-rental-db03f.firebasestorage.app",
  messagingSenderId: "763197939608",
  appId: "1:763197939608:web:adb9138f5eaab55c7595ed"
};

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  const auth = firebase.auth(); // Get the auth instance

  // --- Authentication State Listener ---
auth.onAuthStateChanged(async (user) => {
  if (user) {
    console.log('User is signed in (from auth.js):', user.uid);
    localStorage.setItem('isLoggedIn', 'true');

    try {
      const idToken = await user.getIdToken();
      localStorage.setItem('firebaseIdToken', idToken);
      console.log("Firebase ID Token stored (from auth.js).");

      // Fetch user details from your backend to get roles
      const response = await fetch('http://localhost:5000/api/auth/me', { // Ensure backend is running
        headers: {
          'Authorization': `Bearer ${idToken}`
        }
      });

      if (response.ok) {
        const userData = await response.json();
        localStorage.setItem('currentUserData', JSON.stringify(userData));
        console.log("Local user data (from auth.js):", userData);
        updateNavUI(true, userData.roles); // Call UI update function

        // Handle redirection after login/registration from central place if appropriate
        // This redirection logic might be better placed directly after successful login/register actions
        // or on specific pages checking auth state.
        // For example, if on login.html and user is now logged in:
        if (window.location.pathname.includes('login.html') || window.location.pathname.includes('register.html')) {
             if (userData.roles.includes('ADMIN')) window.location.href = 'admin_dashboard.html';
             else if (userData.roles.includes('OWNER')) window.location.href = 'owner_dashboard.html';
             else window.location.href = 'user_profile.html';
        }


      } else {
        console.error("Failed to fetch user data from backend (auth.js)");
        auth.signOut(); // Important: sign out if backend profile is missing/inaccessible
      }
    } catch (error) {
      console.error("Error getting ID token or fetching user data (auth.js):", error);
      auth.signOut();
    }
  } else {
    console.log('User is signed out (from auth.js).');
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('firebaseIdToken');
    localStorage.removeItem('currentUserData');
    updateNavUI(false, []);

    const protectedPaths = ['user_profile.html', 'owner_dashboard.html', 'admin_dashboard.html', 'owner_add_vehicle.html' /* add more */];
    if (protectedPaths.some(path => window.location.pathname.includes(path))) {
      console.log("Redirecting to login from protected page (auth.js)");
      window.location.href = 'login.html';
    }
  }
});

// --- UI Update Function ---
function updateNavUI(isLoggedIn, roles = []) {
    const navUl = document.querySelector('.main-nav ul');
    if (!navUl) return; // In case nav isn't on the page

    // Clear existing dynamic nav items (login, signup, logout, role-specific)
    const dynamicNavItems = navUl.querySelectorAll('.dynamic-nav-item, a[href="login.html"], a.nav-btn-signup[href="register.html"]');
    dynamicNavItems.forEach(item => {
        if (item.tagName === 'A') item.parentElement.remove(); // If it's an anchor, remove its li parent
        else item.remove(); // If it's an li already
    });
    
    // Find a reference point (e.g., Contact Us link, or just append at the end if simpler)
    const contactLinkLi = navUl.querySelector('a[href="contact.html"]')?.parentElement;

    if (isLoggedIn) {
        if (roles.includes('ADMIN')) addNavLink(navUl, 'Admin Dashboard', 'admin_dashboard.html', contactLinkLi);
        if (roles.includes('OWNER')) addNavLink(navUl, 'Owner Dashboard', 'owner_dashboard.html', contactLinkLi);
        addNavLink(navUl, 'My Profile', 'user_profile.html', contactLinkLi); // Assuming all logged-in users have a profile
        if (roles.includes('RENTER')) addNavLink(navUl, 'My Reservations', 'user_reservations.html', contactLinkLi);

        // Add Logout Button
        let logoutLi = document.createElement('li');
        logoutLi.classList.add('dynamic-nav-item');
        let logoutA = document.createElement('a');
        logoutA.href = "#";
        logoutA.textContent = "Logout";
        logoutA.classList.add('btn', 'btn-secondary', 'nav-btn-signup'); // Re-use styling
        logoutA.style.padding = '0.5rem 1rem'; // Ensure padding
        logoutA.style.color = 'white';      // Ensure text color
        logoutA.onclick = (e) => { e.preventDefault(); auth.signOut(); };
        logoutLi.appendChild(logoutA);
        navUl.appendChild(logoutLi); // Append logout at the end

    } else {
        // Add Login Link
        addNavLink(navUl, 'Login', 'login.html', contactLinkLi);
        
        // Add Sign Up Button
        let signupLi = document.createElement('li');
        signupLi.classList.add('dynamic-nav-item');
        let signupA = document.createElement('a');
        signupA.href = "register.html";
        signupA.textContent = "Sign Up";
        signupA.classList.add('btn', 'btn-primary', 'nav-btn-signup');
        signupA.style.padding = '0.5rem 1rem'; // Ensure padding
        signupA.style.color = 'white';      // Ensure text color
        signupLi.appendChild(signupA);
        navUl.appendChild(signupLi); // Append signup at the end
    }
}

function addNavLink(parentElement, text, href, insertBeforeElement = null) {
    let li = document.createElement('li');
    li.classList.add('dynamic-nav-item');
    let a = document.createElement('a');
    a.href = href;
    a.textContent = text;
    if (window.location.pathname.endsWith(href) || (href === "index.html" && window.location.pathname.endsWith("/"))) {
        a.classList.add('active');
    }
    li.appendChild(a);

    if (insertBeforeElement) {
        parentElement.insertBefore(li, insertBeforeElement.nextSibling); // Insert after the reference
    } else {
        parentElement.appendChild(li); // Fallback to appending at the end
    }
}


// --- Helper function to make authenticated API calls (optional, but good practice) ---
async function fetchWithAuth(url, options = {}) {
  const token = localStorage.getItem('firebaseIdToken');
  if (!token) {
    console.error('No auth token found. Redirecting to login.');
    // window.location.href = 'login.html'; // Or handle differently
    throw new Error('User not authenticated.');
  }

  const headers = {
    ...options.headers,
    'Authorization': `Bearer ${token}`,
    'Content-Type': options.body ? 'application/json' : undefined, // Set Content-Type if body exists
  };
  if (!options.body) delete headers['Content-Type'];


  const response = await fetch(url, { ...options, headers });

  if (response.status === 401) { // Unauthorized (e.g., token expired or invalid)
    console.error('Auth token invalid or expired. Signing out.');
    auth.signOut(); // This will trigger onAuthStateChanged to redirect to login
    throw new Error('Authentication failed.');
  }
  return response;
}
